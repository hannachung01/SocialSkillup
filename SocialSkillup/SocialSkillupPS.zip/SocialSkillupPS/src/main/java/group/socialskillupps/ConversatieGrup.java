package group.socialskillupps;

public class ConversatieGrup extends Conversatie {
    int IDGrup;
    public ConversatieGrup(int IDGrup) {
        super();
        this.IDGrup = IDGrup;
    }
}
