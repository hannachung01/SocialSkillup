package group.socialskillupps;
import java.util.ArrayList;
public abstract class Conversatie {
    ArrayList<Mesaj> mesaje;
    public Conversatie()
    {
        mesaje = new ArrayList<Mesaj>();
    }

}
