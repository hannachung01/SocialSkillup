package group.socialskillupps;

public enum GrupRol {
    LEAD, MID, MEMBER
}

