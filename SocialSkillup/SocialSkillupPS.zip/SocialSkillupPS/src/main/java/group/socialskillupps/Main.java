package group.socialskillupps;

import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;



public class Main extends Application {
    @Override
    public void start(Stage stage) throws Exception
    {
        FXMLLoader root = new FXMLLoader(Main.class.getResource("hello-view.fxml"));
        Scene intro = new Scene(root.load(), Color.BLACK);
        Image icon = new Image("logo.jpg");
        stage.getIcons().add(icon);
        stage.setWidth(300);
        stage.setHeight(500);
        stage.setTitle("Welcome to SocialSkillup!");
        stage.setScene(intro);
        stage.show();
        PauseTransition pauza = new PauseTransition(Duration.seconds(2));
        pauza.play();
        FXMLLoader fl2 = new FXMLLoader(Main.class.getResource("login.fxml"));;
        Scene scene2 = new Scene(fl2.load(), 320, 500);
        pauza.setOnFinished(event -> {
            stage.setTitle("Login");
            stage.setScene(scene2);
        });
    }

    public static void main(String[] args) {
        launch();
    }
}
   /*

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

*/