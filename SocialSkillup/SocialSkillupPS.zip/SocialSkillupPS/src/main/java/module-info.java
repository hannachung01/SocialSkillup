module group.socialskillupps {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mail;
    requires org.xerial.sqlitejdbc;


    opens group.socialskillupps to javafx.fxml;
    exports group.socialskillupps;
}